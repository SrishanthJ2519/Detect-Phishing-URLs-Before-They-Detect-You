import { useState, useEffect } from 'react';
import { Clock, Search, Trash2, Filter, CheckCircle, AlertTriangle, XCircle, ExternalLink } from 'lucide-react';
import { getStoredHistory, clearHistory, type ScanResult } from '../utils/scanSimulator';

interface HistoryPageProps {
  onNavigate: (page: string, result?: ScanResult) => void;
}

type FilterType = 'all' | 'safe' | 'suspicious' | 'phishing';

export default function HistoryPage({ onNavigate }: HistoryPageProps) {
  const [history, setHistory] = useState<ScanResult[]>([]);
  const [filter, setFilter] = useState<FilterType>('all');
  const [search, setSearch] = useState('');
  const [cleared, setCleared] = useState(false);

  useEffect(() => {
    const stored = getStoredHistory();
    if (stored.length === 0) {
      // Add demo data
      const demo: ScanResult[] = [
        {
          url: 'https://google.com', domain: 'google.com', status: 'SAFE', riskScore: 5,
          threatLevel: 'LOW', scanTime: '0.82s', date: 'Jun 12, 2024',
          checks: { httpsCheck: true, domainAnalysis: true, suspiciousKeywords: true, urlStructure: true, ipDetection: true, sslCertificate: true, domainAge: true, maliciousPattern: true },
          detectedIssues: [], recommendation: 'Safe website.', urlReputation: 95, securityScore: 95,
        },
        {
          url: 'http://paypa1-secure-login.tk/verify', domain: 'paypa1-secure-login.tk', status: 'PHISHING', riskScore: 92,
          threatLevel: 'CRITICAL', scanTime: '2.14s', date: 'Jun 12, 2024',
          checks: { httpsCheck: false, domainAnalysis: false, suspiciousKeywords: false, urlStructure: false, ipDetection: true, sslCertificate: false, domainAge: false, maliciousPattern: false },
          detectedIssues: ['Suspicious TLD', 'No HTTPS', 'Phishing keywords'], recommendation: 'Do not visit.', urlReputation: 8, securityScore: 8,
        },
        {
          url: 'https://github.com', domain: 'github.com', status: 'SAFE', riskScore: 3,
          threatLevel: 'LOW', scanTime: '0.67s', date: 'Jun 11, 2024',
          checks: { httpsCheck: true, domainAnalysis: true, suspiciousKeywords: true, urlStructure: true, ipDetection: true, sslCertificate: true, domainAge: true, maliciousPattern: true },
          detectedIssues: [], recommendation: 'Safe website.', urlReputation: 97, securityScore: 97,
        },
        {
          url: 'http://amazon-account-suspended.xyz/update', domain: 'amazon-account-suspended.xyz', status: 'PHISHING', riskScore: 88,
          threatLevel: 'HIGH', scanTime: '1.96s', date: 'Jun 11, 2024',
          checks: { httpsCheck: false, domainAnalysis: false, suspiciousKeywords: false, urlStructure: false, ipDetection: true, sslCertificate: false, domainAge: false, maliciousPattern: false },
          detectedIssues: ['Suspicious domain', 'No HTTPS', 'Suspicious keywords'], recommendation: 'Phishing site detected.', urlReputation: 12, securityScore: 12,
        },
        {
          url: 'https://secure-bank-login-verify.top/account', domain: 'secure-bank-login-verify.top', status: 'SUSPICIOUS', riskScore: 55,
          threatLevel: 'MEDIUM', scanTime: '1.33s', date: 'Jun 10, 2024',
          checks: { httpsCheck: true, domainAnalysis: false, suspiciousKeywords: false, urlStructure: false, ipDetection: true, sslCertificate: true, domainAge: false, maliciousPattern: false },
          detectedIssues: ['Suspicious keywords', 'Unusual domain'], recommendation: 'Proceed with caution.', urlReputation: 45, securityScore: 45,
        },
        {
          url: 'https://microsoft.com', domain: 'microsoft.com', status: 'SAFE', riskScore: 4,
          threatLevel: 'LOW', scanTime: '0.71s', date: 'Jun 10, 2024',
          checks: { httpsCheck: true, domainAnalysis: true, suspiciousKeywords: true, urlStructure: true, ipDetection: true, sslCertificate: true, domainAge: true, maliciousPattern: true },
          detectedIssues: [], recommendation: 'Safe website.', urlReputation: 96, securityScore: 96,
        },
      ];
      setHistory(demo);
    } else {
      setHistory(stored);
    }
  }, []);

  const handleClear = () => {
    clearHistory();
    setHistory([]);
    setCleared(true);
    setTimeout(() => setCleared(false), 3000);
  };

  const filtered = history.filter(h => {
    const matchFilter = filter === 'all' || h.status.toLowerCase() === filter;
    const matchSearch = h.url.toLowerCase().includes(search.toLowerCase()) ||
      h.domain.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const counts = {
    all: history.length,
    safe: history.filter(h => h.status === 'SAFE').length,
    suspicious: history.filter(h => h.status === 'SUSPICIOUS').length,
    phishing: history.filter(h => h.status === 'PHISHING').length,
  };

  const getStatusIcon = (status: string) => {
    if (status === 'SAFE') return <CheckCircle className="w-4 h-4 text-green-400" />;
    if (status === 'SUSPICIOUS') return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
    return <XCircle className="w-4 h-4 text-red-400" />;
  };

  const getStatusBadge = (status: string) => {
    if (status === 'SAFE') return 'bg-green-500/10 text-green-400 border-green-500/25';
    if (status === 'SUSPICIOUS') return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/25';
    return 'bg-red-500/10 text-red-400 border-red-500/25';
  };

  const getRiskColor = (score: number) => {
    if (score <= 25) return 'text-green-400';
    if (score <= 50) return 'text-yellow-400';
    if (score <= 75) return 'text-orange-400';
    return 'text-red-400';
  };

  return (
    <div className="min-h-screen grid-bg pt-16 px-4 py-10">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 animate-slide-up">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-3">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs text-slate-400 tracking-widest uppercase">Scan History</span>
            </div>
            <h1 className="text-3xl font-black text-white">
              Analysis <span className="neon-text">History</span>
            </h1>
            <p className="text-slate-500 text-sm mt-1">{history.length} URLs analyzed</p>
          </div>
          {history.length > 0 && (
            <button onClick={handleClear} className="btn-danger px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2">
              <Trash2 className="w-4 h-4" /> Clear History
            </button>
          )}
        </div>

        {cleared && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/25 rounded-xl text-red-400 text-sm animate-fade-in">
            History cleared successfully.
          </div>
        )}

        {/* Stats mini cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {[
            { label: 'Total Scans', value: counts.all, color: 'text-cyan-400' },
            { label: 'Safe', value: counts.safe, color: 'text-green-400' },
            { label: 'Suspicious', value: counts.suspicious, color: 'text-yellow-400' },
            { label: 'Phishing', value: counts.phishing, color: 'text-red-400' },
          ].map((s, i) => (
            <div key={i} className="glass neon-border rounded-xl px-4 py-3 text-center">
              <div className={`text-2xl font-black ${s.color}`}>{s.value}</div>
              <div className="text-xs text-slate-600 uppercase tracking-widest">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Filters + search */}
        <div className="glass neon-border rounded-2xl p-4 mb-6 flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search URLs..."
              className="w-full pl-10 pr-4 py-2.5 bg-transparent text-white text-sm placeholder-slate-600 border border-slate-700 rounded-xl focus:ring-0 transition-all"
            />
          </div>

          {/* Filter tabs */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <Filter className="w-4 h-4 text-slate-500" />
            {(['all', 'safe', 'suspicious', 'phishing'] as FilterType[]).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-2 rounded-lg text-xs font-semibold capitalize transition-all ${
                  filter === f
                    ? f === 'safe' ? 'bg-green-500/20 text-green-400 border border-green-500/40'
                    : f === 'suspicious' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/40'
                    : f === 'phishing' ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                    : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                    : 'text-slate-500 border border-slate-700 hover:border-slate-600'
                }`}
              >
                {f} ({counts[f]})
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        {filtered.length === 0 ? (
          <div className="glass neon-border rounded-2xl p-12 text-center">
            <Clock className="w-12 h-12 text-slate-700 mx-auto mb-3" />
            <p className="text-slate-500">No scan history found.</p>
            <button onClick={() => onNavigate('scanner')} className="btn-cyan mt-4 px-5 py-2 rounded-lg text-sm font-semibold">
              Start Scanning
            </button>
          </div>
        ) : (
          <div className="glass neon-border rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/50">
                    <th className="text-left text-slate-500 text-xs uppercase tracking-widest px-5 py-4">URL</th>
                    <th className="text-left text-slate-500 text-xs uppercase tracking-widest px-4 py-4">Date</th>
                    <th className="text-left text-slate-500 text-xs uppercase tracking-widest px-4 py-4">Time</th>
                    <th className="text-left text-slate-500 text-xs uppercase tracking-widest px-4 py-4">Result</th>
                    <th className="text-left text-slate-500 text-xs uppercase tracking-widest px-4 py-4">Risk %</th>
                    <th className="text-left text-slate-500 text-xs uppercase tracking-widest px-4 py-4">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {filtered.map((item, i) => (
                    <tr key={i} className="table-row-hover">
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(item.status)}
                          <div>
                            <div className="text-slate-300 font-mono text-xs truncate max-w-xs">{item.domain}</div>
                            <div className="text-slate-600 text-xs truncate max-w-xs">{item.url.length > 50 ? item.url.slice(0, 50) + '...' : item.url}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-400 text-xs whitespace-nowrap">{item.date}</td>
                      <td className="px-4 py-3.5 text-slate-400 text-xs whitespace-nowrap">{item.scanTime}</td>
                      <td className="px-4 py-3.5">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md border text-xs font-semibold ${getStatusBadge(item.status)}`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 bg-slate-800 rounded-full w-16 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${item.riskScore > 50 ? 'bg-red-400' : item.riskScore > 25 ? 'bg-yellow-400' : 'bg-green-400'}`}
                              style={{ width: `${item.riskScore}%` }}
                            />
                          </div>
                          <span className={`text-xs font-bold ${getRiskColor(item.riskScore)}`}>{item.riskScore}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <button
                          onClick={() => onNavigate('dashboard', item)}
                          className="flex items-center gap-1 text-xs text-cyan-500 hover:text-cyan-400 transition-colors"
                        >
                          <ExternalLink className="w-3.5 h-3.5" /> View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
