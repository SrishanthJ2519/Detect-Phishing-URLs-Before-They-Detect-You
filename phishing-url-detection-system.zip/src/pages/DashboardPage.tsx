import { useState } from 'react';
import {
  Shield, AlertTriangle, CheckCircle, XCircle, Download,
  FileText, Globe, Lock, Activity, TrendingUp, Clock,
  ChevronDown, Loader2
} from 'lucide-react';
import { type ScanResult } from '../utils/scanSimulator';
import { exportAsTXT, exportAsCSV, exportAsPDF } from '../utils/exportReport';

interface DashboardPageProps {
  result: ScanResult | null;
  onNavigate: (page: string) => void;
}

function CircleScore({ value, color, label }: { value: number; color: string; label: string }) {
  const r = 40;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-24 h-24">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
          <circle
            cx="50" cy="50" r={r}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 1.5s cubic-bezier(0.4,0,0.2,1)', filter: `drop-shadow(0 0 6px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-white font-black text-xl">{value}%</span>
        </div>
      </div>
      <span className="text-xs text-slate-500 uppercase tracking-widest">{label}</span>
    </div>
  );
}

const EMPTY_RESULT: ScanResult = {
  url: 'https://example-phishing-site.tk/verify-account',
  domain: 'example-phishing-site.tk',
  status: 'PHISHING',
  riskScore: 87,
  threatLevel: 'HIGH',
  scanTime: '1.94s',
  date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' }),
  checks: {
    httpsCheck: false,
    domainAnalysis: false,
    suspiciousKeywords: false,
    urlStructure: false,
    ipDetection: true,
    sslCertificate: false,
    domainAge: false,
    maliciousPattern: false,
  },
  detectedIssues: [
    'Suspicious top-level domain detected',
    'Phishing keyword "verify" found in URL',
    'No HTTPS security protocol',
    'Multiple suspicious subdomains',
  ],
  recommendation: 'WARNING: This website is likely a phishing site. Do NOT enter any personal information.',
  urlReputation: 13,
  securityScore: 13,
};

export default function DashboardPage({ result, onNavigate }: DashboardPageProps) {
  const data = result || EMPTY_RESULT;
  const [showExport, setShowExport] = useState(false);
  const [exporting, setExporting] = useState('');
  const [exportSuccess, setExportSuccess] = useState('');

  const handleExport = async (type: 'pdf' | 'txt' | 'csv') => {
    setExporting(type);
    setShowExport(false);
    try {
      if (type === 'pdf') await exportAsPDF(data);
      else if (type === 'txt') exportAsTXT(data);
      else exportAsCSV(data);
      setExportSuccess(`${type.toUpperCase()} Report Generated Successfully! ✓`);
    } catch (e) {
      console.error(e);
    } finally {
      setExporting('');
      setTimeout(() => setExportSuccess(''), 4000);
    }
  };

  const getStatusColor = () => {
    if (data.status === 'SAFE') return '#00ff88';
    if (data.status === 'SUSPICIOUS') return '#ffaa00';
    return '#ff4444';
  };

  const indicators = [
    {
      label: 'Domain Safety',
      value: data.checks.domainAnalysis,
      icon: Globe,
    },
    {
      label: 'SSL Certificate',
      value: data.checks.sslCertificate,
      icon: Lock,
    },
    {
      label: 'Suspicious Pattern',
      value: data.checks.maliciousPattern,
      icon: AlertTriangle,
    },
    {
      label: 'Malicious Keywords',
      value: data.checks.suspiciousKeywords,
      icon: FileText,
    },
  ];

  return (
    <div className="min-h-screen grid-bg pt-16 px-4 py-10">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 animate-slide-up">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-3">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs text-slate-400 tracking-widest uppercase">Security Dashboard</span>
            </div>
            <h1 className="text-3xl font-black text-white">
              Result <span className="neon-text">Analysis</span>
            </h1>
            <p className="text-slate-500 text-sm mt-1 font-mono truncate max-w-md">{data.url}</p>
          </div>

          {/* Export Button */}
          <div className="relative">
            <button
              onClick={() => setShowExport(!showExport)}
              disabled={!!exporting}
              className="btn-cyan px-5 py-3 rounded-xl font-semibold text-sm flex items-center gap-2 neon-glow"
            >
              {exporting
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</>
                : <><Download className="w-4 h-4" /> Export Report <ChevronDown className="w-3.5 h-3.5" /></>
              }
            </button>
            {showExport && (
              <div className="absolute right-0 top-full mt-2 glass-strong neon-border rounded-xl overflow-hidden z-20 min-w-40 animate-fade-in">
                {[
                  { type: 'pdf' as const, label: 'PDF Report', icon: FileText },
                  { type: 'txt' as const, label: 'TXT Report', icon: FileText },
                  { type: 'csv' as const, label: 'CSV Data', icon: FileText },
                ].map(({ type, label, icon: Icon }) => (
                  <button
                    key={type}
                    onClick={() => handleExport(type)}
                    className="w-full px-4 py-3 flex items-center gap-3 text-sm text-slate-300 hover:text-cyan-400 hover:bg-cyan-500/10 transition-all text-left border-b border-slate-800 last:border-0"
                  >
                    <Icon className="w-4 h-4" />
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Export success toast */}
        {exportSuccess && (
          <div className="mb-6 p-4 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm flex items-center gap-2 animate-slide-up">
            <CheckCircle className="w-4 h-4" />
            {exportSuccess}
          </div>
        )}

        {/* Demo note if no real result */}
        {!result && (
          <div className="mb-6 p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-xl text-cyan-400/70 text-xs flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Demo mode — Scan a URL from the <button onClick={() => onNavigate('scanner')} className="underline hover:text-cyan-400">Scanner page</button> to see real results here.
          </div>
        )}

        {/* Top metrics grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Security Score', value: `${data.securityScore}%`, icon: Shield, color: data.securityScore > 60 ? 'text-green-400' : 'text-red-400', bg: 'bg-cyan-500/5', border: 'border-cyan-500/20' },
            { label: 'Threat Level', value: data.threatLevel, icon: AlertTriangle, color: data.threatLevel === 'LOW' ? 'text-green-400' : data.threatLevel === 'HIGH' || data.threatLevel === 'CRITICAL' ? 'text-red-400' : 'text-yellow-400', bg: 'bg-slate-800/50', border: 'border-slate-700/50' },
            { label: 'URL Reputation', value: `${data.urlReputation}%`, icon: TrendingUp, color: 'text-cyan-400', bg: 'bg-cyan-500/5', border: 'border-cyan-500/20' },
            { label: 'Scan Time', value: data.scanTime, icon: Clock, color: 'text-slate-300', bg: 'bg-slate-800/50', border: 'border-slate-700/50' },
          ].map((card, i) => (
            <div key={i} className={`glass rounded-2xl p-5 border ${card.border} card-hover`}>
              <div className="flex items-start justify-between mb-3">
                <card.icon className={`w-5 h-5 ${card.color}`} />
                <div className={`w-2 h-2 rounded-full animate-blink ${card.color.replace('text-', 'bg-')}`} />
              </div>
              <div className={`text-2xl font-black ${card.color} mb-1`}>{card.value}</div>
              <div className="text-xs text-slate-600 uppercase tracking-widest">{card.label}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          {/* Score circles */}
          <div className="glass neon-border rounded-2xl p-6">
            <h3 className="text-white font-semibold mb-5 flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" /> Score Overview
            </h3>
            <div className="flex justify-around">
              <CircleScore value={data.securityScore} color={getStatusColor()} label="Security" />
              <CircleScore value={data.urlReputation} color="#00d4ff" label="Reputation" />
              <CircleScore value={Math.max(0, 100 - data.riskScore)} color="#8b5cf6" label="Trust" />
            </div>
          </div>

          {/* Threat Indicators */}
          <div className="glass neon-border rounded-2xl p-6 lg:col-span-2">
            <h3 className="text-white font-semibold mb-5 flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" /> Threat Indicators
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {indicators.map(({ label, value, icon: Icon }) => (
                <div
                  key={label}
                  className={`flex items-center gap-3 p-4 rounded-xl border ${
                    value ? 'border-green-500/20 bg-green-500/5' : 'border-red-500/20 bg-red-500/5'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${value ? 'text-green-400' : 'text-red-400'}`} />
                  <div>
                    <div className="text-sm text-slate-300 font-medium">{label}</div>
                    <div className={`text-xs font-bold ${value ? 'text-green-400' : 'text-red-400'}`}>
                      {value ? '✓ SAFE' : '✗ DETECTED'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Full checks table */}
        <div className="glass neon-border rounded-2xl p-6 mb-6">
          <h3 className="text-white font-semibold mb-5 flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" /> Detailed Analysis Results
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left text-slate-500 text-xs uppercase tracking-widest pb-3 pr-4">Check</th>
                  <th className="text-left text-slate-500 text-xs uppercase tracking-widest pb-3 pr-4">Status</th>
                  <th className="text-left text-slate-500 text-xs uppercase tracking-widest pb-3">Impact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {[
                  { label: 'HTTPS Security', key: 'httpsCheck', impact: 'High' },
                  { label: 'Domain Analysis', key: 'domainAnalysis', impact: 'High' },
                  { label: 'Suspicious Keywords', key: 'suspiciousKeywords', impact: 'Medium' },
                  { label: 'URL Structure', key: 'urlStructure', impact: 'Medium' },
                  { label: 'IP Address Detection', key: 'ipDetection', impact: 'High' },
                  { label: 'SSL Certificate', key: 'sslCertificate', impact: 'Critical' },
                  { label: 'Domain Age', key: 'domainAge', impact: 'Medium' },
                  { label: 'Malicious Pattern', key: 'maliciousPattern', impact: 'Critical' },
                ].map(({ label, key, impact }) => {
                  const passed = data.checks[key as keyof typeof data.checks];
                  return (
                    <tr key={key} className="table-row-hover">
                      <td className="py-3 pr-4 text-slate-300">{label}</td>
                      <td className="py-3 pr-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold ${
                          passed ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                        }`}>
                          {passed ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                          {passed ? 'PASS' : 'FAIL'}
                        </span>
                      </td>
                      <td className="py-3">
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          impact === 'Critical' ? 'text-red-400 bg-red-500/10' :
                          impact === 'High' ? 'text-orange-400 bg-orange-500/10' :
                          'text-yellow-400 bg-yellow-500/10'
                        }`}>{impact}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recommendation */}
        <div className={`glass rounded-2xl p-6 border ${data.status === 'SAFE' ? 'glow-green' : 'glow-red'}`}>
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
              data.status === 'SAFE' ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'
            }`}>
              {data.status === 'SAFE'
                ? <CheckCircle className="w-6 h-6 text-green-400" />
                : <AlertTriangle className="w-6 h-6 text-red-400" />
              }
            </div>
            <div>
              <h3 className={`font-bold mb-2 ${data.status === 'SAFE' ? 'text-green-400' : 'text-red-400'}`}>
                Security Recommendation
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed">{data.recommendation}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
