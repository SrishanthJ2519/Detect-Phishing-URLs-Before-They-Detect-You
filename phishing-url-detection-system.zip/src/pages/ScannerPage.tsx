import { useState, useEffect, useRef } from 'react';
import {
  Shield, Search, Globe, AlertTriangle, CheckCircle, XCircle,
  Lock, Wifi, Key, FileSearch, Cpu, Activity, ChevronRight, RotateCcw
} from 'lucide-react';
import { simulateScan, addToHistory, type ScanResult } from '../utils/scanSimulator';

interface ScannerPageProps {
  initialUrl?: string;
  onNavigate: (page: string, result?: ScanResult) => void;
}

const SCAN_STEPS = [
  'Resolving domain name...',
  'Checking HTTPS protocol...',
  'Analyzing URL structure...',
  'Detecting suspicious keywords...',
  'Verifying SSL certificate...',
  'Analyzing domain age & reputation...',
  'Running threat intelligence check...',
  'Generating security report...',
];

const CHECKS_CONFIG = [
  { key: 'httpsCheck', label: 'HTTPS Security Check', icon: Lock },
  { key: 'domainAnalysis', label: 'Domain Analysis', icon: Globe },
  { key: 'suspiciousKeywords', label: 'Suspicious Keyword Detection', icon: Key },
  { key: 'urlStructure', label: 'URL Structure Analysis', icon: FileSearch },
  { key: 'ipDetection', label: 'IP Address Detection', icon: Wifi },
  { key: 'sslCertificate', label: 'SSL Certificate Verification', icon: Shield },
  { key: 'domainAge', label: 'Domain Age Analysis', icon: Activity },
  { key: 'maliciousPattern', label: 'Malicious Pattern Detection', icon: Cpu },
];

export default function ScannerPage({ initialUrl, onNavigate }: ScannerPageProps) {
  const [url, setUrl] = useState(initialUrl || '');
  const [scanning, setScanning] = useState(false);
  const [scanStep, setScanStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState('');
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const stepRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (initialUrl) {
      setUrl(initialUrl);
    }
  }, [initialUrl]);

  const startScan = async () => {
    if (!url.trim()) {
      setError('Please enter a URL to scan.');
      return;
    }
    setError('');
    setResult(null);
    setScanning(true);
    setScanStep(0);
    setProgress(0);

    // Animate progress
    let p = 0;
    progressRef.current = setInterval(() => {
      p += Math.random() * 3 + 1;
      if (p >= 90) {
        p = 90;
        if (progressRef.current) clearInterval(progressRef.current);
      }
      setProgress(Math.min(p, 90));
    }, 120);

    // Animate steps
    let step = 0;
    stepRef.current = setInterval(() => {
      step++;
      if (step >= SCAN_STEPS.length) {
        if (stepRef.current) clearInterval(stepRef.current);
      }
      setScanStep(step);
    }, 420);

    try {
      const res = await simulateScan(url);
      if (progressRef.current) clearInterval(progressRef.current);
      if (stepRef.current) clearInterval(stepRef.current);
      setProgress(100);
      setScanStep(SCAN_STEPS.length - 1);
      setResult(res);
      setScanning(false);
      addToHistory(res);
    } catch {
      setScanning(false);
      setError('Scan failed. Please try again.');
    }
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !scanning) startScan();
  };

  const reset = () => {
    setResult(null);
    setUrl('');
    setProgress(0);
    setScanStep(0);
  };

  const getStatusColor = (status: string) => {
    if (status === 'SAFE') return 'text-green-400';
    if (status === 'SUSPICIOUS') return 'text-yellow-400';
    return 'text-red-400';
  };

  const getStatusGlow = (status: string) => {
    if (status === 'SAFE') return 'glow-green';
    if (status === 'SUSPICIOUS') return 'glow-yellow';
    return 'glow-red';
  };

  const getThreatColor = (level: string) => {
    if (level === 'LOW') return 'text-green-400 bg-green-400/10 border-green-400/30';
    if (level === 'MEDIUM') return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30';
    if (level === 'HIGH') return 'text-orange-400 bg-orange-400/10 border-orange-400/30';
    return 'text-red-400 bg-red-400/10 border-red-400/30';
  };

  const getRiskBarColor = (score: number) => {
    if (score <= 25) return 'bg-green-400';
    if (score <= 50) return 'bg-yellow-400';
    if (score <= 75) return 'bg-orange-400';
    return 'bg-red-400';
  };

  return (
    <div className="min-h-screen grid-bg pt-16 px-4 py-10">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10 animate-slide-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-4">
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs text-slate-400 tracking-widest uppercase">URL Security Scanner</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-2">
            Scan <span className="neon-text">Any URL</span>
          </h1>
          <p className="text-slate-500">Enter a URL below to analyze it for phishing and malicious content.</p>
        </div>

        {/* Scanner Input */}
        <div className="glass neon-border rounded-2xl p-6 mb-6 animate-slide-up">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="url"
                value={url}
                onChange={e => setUrl(e.target.value)}
                onKeyDown={handleKey}
                placeholder="https://example.com"
                disabled={scanning}
                className="w-full pl-12 pr-4 py-3.5 glass rounded-xl text-white placeholder-slate-600 bg-transparent text-sm border border-cyan-500/20 disabled:opacity-50 transition-all"
              />
            </div>
            {result ? (
              <button onClick={reset} className="btn-cyan px-5 py-3.5 rounded-xl font-semibold text-sm flex items-center gap-2">
                <RotateCcw className="w-4 h-4" /> New Scan
              </button>
            ) : (
              <button
                onClick={startScan}
                disabled={scanning}
                className="btn-cyan px-5 py-3.5 rounded-xl font-semibold text-sm flex items-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {scanning ? (
                  <>
                    <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" /> Start Scan
                  </>
                )}
              </button>
            )}
          </div>
          {error && <p className="mt-3 text-red-400 text-sm">{error}</p>}
        </div>

        {/* Scanning animation */}
        {scanning && (
          <div className="glass neon-border rounded-2xl p-8 mb-6 animate-fade-in">
            <div className="flex flex-col items-center gap-6">
              {/* Radar animation */}
              <div className="relative w-32 h-32">
                <div className="absolute inset-0 rounded-full border-2 border-cyan-500/30" />
                <div className="absolute inset-4 rounded-full border border-cyan-500/20" />
                <div className="absolute inset-8 rounded-full border border-cyan-500/15" />
                {/* Rotating sweep */}
                <div className="absolute inset-0 rounded-full overflow-hidden">
                  <div
                    className="absolute top-1/2 left-1/2 w-1/2 h-0.5 origin-left animate-radar"
                    style={{
                      background: 'linear-gradient(to right, rgba(0,212,255,0.8), transparent)',
                      transformOrigin: '0 50%',
                    }}
                  />
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Shield className="w-8 h-8 text-cyan-400 animate-pulse" />
                </div>
              </div>

              <div className="text-center">
                <p className="text-cyan-400 font-bold text-lg mb-1">Analyzing URL...</p>
                <p className="text-slate-500 text-sm min-h-5 transition-all">
                  {SCAN_STEPS[Math.min(scanStep, SCAN_STEPS.length - 1)]}
                </p>
              </div>

              {/* Progress bar */}
              <div className="w-full max-w-sm">
                <div className="flex justify-between text-xs text-slate-500 mb-2">
                  <span>Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full progress-bar-anim"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              {/* Scan steps */}
              <div className="w-full max-w-sm space-y-2">
                {SCAN_STEPS.slice(0, 4).map((step, i) => (
                  <div key={i} className={`flex items-center gap-3 text-sm transition-all duration-300 ${i <= scanStep ? 'text-slate-300' : 'text-slate-700'}`}>
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 ${
                      i < scanStep ? 'bg-green-500' : i === scanStep ? 'bg-cyan-500 animate-pulse' : 'bg-slate-700'
                    }`}>
                      {i < scanStep && <CheckCircle className="w-3 h-3 text-white" />}
                    </div>
                    <span className="text-xs">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Result Card */}
        {result && !scanning && (
          <div className={`glass rounded-2xl p-6 mb-6 border animate-slide-up ${getStatusGlow(result.status)}`}>
            {/* Status Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-800">
              <div>
                <div className="text-slate-500 text-xs uppercase tracking-widest mb-1">Scanned Website</div>
                <div className="text-white font-mono font-semibold text-sm truncate max-w-xs">{result.domain}</div>
              </div>
              <div className="flex items-center gap-3">
                <div className={`px-4 py-2 rounded-lg border font-black text-xl flex items-center gap-2 ${getStatusColor(result.status)} ${getThreatColor(result.threatLevel)}`}>
                  {result.status === 'SAFE' ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                  {result.status}
                </div>
              </div>
            </div>

            {/* Score + Threat */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="glass rounded-xl p-4 text-center">
                <div className="text-2xl font-black mb-1" style={{ color: result.riskScore > 50 ? '#ff4444' : result.riskScore > 25 ? '#ffaa00' : '#00ff88' }}>
                  {result.riskScore}%
                </div>
                <div className="text-xs text-slate-500">Risk Score</div>
              </div>
              <div className="glass rounded-xl p-4 text-center">
                <div className={`text-lg font-black mb-1 ${getStatusColor(result.status)}`}>{result.threatLevel}</div>
                <div className="text-xs text-slate-500">Threat Level</div>
              </div>
              <div className="glass rounded-xl p-4 text-center">
                <div className="text-2xl font-black text-cyan-400 mb-1">{result.securityScore}%</div>
                <div className="text-xs text-slate-500">Security Score</div>
              </div>
              <div className="glass rounded-xl p-4 text-center">
                <div className="text-lg font-black text-slate-300 mb-1">{result.scanTime}</div>
                <div className="text-xs text-slate-500">Scan Time</div>
              </div>
            </div>

            {/* Risk Progress Bar */}
            <div className="mb-6">
              <div className="flex justify-between text-xs text-slate-500 mb-2">
                <span>Risk Level</span>
                <span>{result.riskScore}%</span>
              </div>
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full progress-bar-anim ${getRiskBarColor(result.riskScore)}`}
                  style={{ width: `${result.riskScore}%`, boxShadow: result.riskScore > 50 ? '0 0 10px rgba(255,68,68,0.5)' : '0 0 10px rgba(0,255,136,0.5)' }}
                />
              </div>
            </div>

            {/* Detection Checks */}
            <div className="mb-6">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                <Shield className="w-4 h-4 text-cyan-400" /> Detection Checks
              </h3>
              <div className="grid sm:grid-cols-2 gap-2">
                {CHECKS_CONFIG.map(({ key, label, icon: Icon }) => {
                  const passed = result.checks[key as keyof typeof result.checks];
                  return (
                    <div
                      key={key}
                      className={`flex items-center gap-3 px-4 py-2.5 rounded-lg border text-sm ${
                        passed
                          ? 'border-green-500/20 bg-green-500/5 text-green-400'
                          : 'border-red-500/20 bg-red-500/5 text-red-400'
                      }`}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      <span className="flex-1 text-slate-300 text-xs">{label}</span>
                      {passed
                        ? <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                        : <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                      }
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Detected Issues */}
            {result.detectedIssues.length > 0 && (
              <div className="mb-6 p-4 bg-red-500/5 border border-red-500/20 rounded-xl">
                <h3 className="text-red-400 font-semibold mb-2 flex items-center gap-2 text-sm">
                  <AlertTriangle className="w-4 h-4" /> Detected Issues
                </h3>
                <ul className="space-y-1">
                  {result.detectedIssues.map((issue, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                      <span className="text-red-400 mt-0.5">⚠</span>
                      {issue}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Recommendation */}
            <div className={`p-4 rounded-xl border ${result.status === 'SAFE' ? 'bg-green-500/5 border-green-500/20' : 'bg-yellow-500/5 border-yellow-500/20'}`}>
              <h3 className={`font-semibold mb-1 text-sm flex items-center gap-2 ${result.status === 'SAFE' ? 'text-green-400' : 'text-yellow-400'}`}>
                <Shield className="w-4 h-4" /> Recommendation
              </h3>
              <p className="text-slate-300 text-sm">{result.recommendation}</p>
            </div>

            {/* Actions */}
            <div className="mt-6 flex flex-wrap gap-3 justify-end">
              <button
                onClick={() => onNavigate('dashboard', result)}
                className="btn-cyan px-5 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2"
              >
                Full Dashboard <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Sample URLs */}
        {!scanning && !result && (
          <div className="glass neon-border rounded-2xl p-6 animate-fade-in">
            <h3 className="text-slate-400 text-sm font-semibold mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" /> Try these sample URLs
            </h3>
            <div className="flex flex-wrap gap-2">
              {[
                'https://google.com',
                'http://paypa1-secure-login.tk/verify',
                'https://192.168.1.1/login',
                'https://github.com',
                'http://amazon-account-suspended.xyz/update',
                'https://microsoft.com',
              ].map(sample => (
                <button
                  key={sample}
                  onClick={() => setUrl(sample)}
                  className="px-3 py-1.5 rounded-lg text-xs text-slate-400 border border-slate-700 hover:border-cyan-500/40 hover:text-cyan-400 transition-all font-mono"
                >
                  {sample.length > 35 ? sample.slice(0, 35) + '...' : sample}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
