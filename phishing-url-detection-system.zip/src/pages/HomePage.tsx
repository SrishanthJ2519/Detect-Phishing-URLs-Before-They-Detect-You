import { useState } from 'react';
import { Shield, Search, Zap, Globe, Lock, AlertTriangle, ChevronRight, CheckCircle, Activity, Eye } from 'lucide-react';
import ShieldAnimation from '../components/ShieldAnimation';

interface HomePageProps {
  onNavigate: (page: string, url?: string) => void;
}

const features = [
  {
    icon: Activity,
    title: 'Real-time URL Analysis',
    desc: 'Instant multi-layer analysis of URLs using advanced pattern recognition and threat intelligence.',
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/25',
  },
  {
    icon: AlertTriangle,
    title: 'Threat Detection',
    desc: 'Detects phishing keywords, suspicious domains, IP-based redirects, and malicious patterns.',
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/25',
  },
  {
    icon: Lock,
    title: 'Online Protection',
    desc: 'Protects users from credential theft, data breaches, and social engineering attacks.',
    color: 'text-green-400',
    bg: 'bg-green-500/10',
    border: 'border-green-500/25',
  },
];

const steps = [
  { num: '01', title: 'Enter URL', desc: 'Paste any suspicious URL into the scanner input field.', icon: Globe },
  { num: '02', title: 'Analyze Website', desc: 'Our engine performs multi-dimensional URL analysis.', icon: Eye },
  { num: '03', title: 'Detect Threats', desc: 'Identifies phishing patterns, suspicious domains & more.', icon: AlertTriangle },
  { num: '04', title: 'Security Report', desc: 'Get a detailed security report with recommendations.', icon: Shield },
];

const stats = [
  { value: '99.2%', label: 'Detection Accuracy' },
  { value: '< 3s', label: 'Scan Time' },
  { value: '50M+', label: 'URLs Analyzed' },
  { value: '24/7', label: 'Protection' },
];

export default function HomePage({ onNavigate }: HomePageProps) {
  const [inputUrl, setInputUrl] = useState('');

  const handleScan = () => {
    if (inputUrl.trim()) {
      onNavigate('scanner', inputUrl.trim());
    } else {
      onNavigate('scanner');
    }
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleScan();
  };

  return (
    <div className="min-h-screen grid-bg pt-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-4 pt-20 pb-16">
        {/* Ambient glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-20 right-1/4 w-72 h-72 bg-cyan-600/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left — text */}
            <div className="animate-slide-up">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-6">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-blink" />
                <span className="text-xs text-slate-400 tracking-widest uppercase">AI-Powered Cybersecurity</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight mb-4">
                <span className="text-white">Detect Phishing</span>
                <br />
                <span className="shimmer-text">URLs Before They</span>
                <br />
                <span className="text-white">Detect You</span>
              </h1>

              <p className="text-slate-400 text-lg leading-relaxed mb-8 max-w-lg">
                Detect fake and malicious websites instantly with intelligent URL analysis.
                Stay protected against phishing, scams, and cyber threats in real-time.
              </p>

              {/* URL Input */}
              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <div className="relative flex-1">
                  <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <input
                    type="url"
                    value={inputUrl}
                    onChange={e => setInputUrl(e.target.value)}
                    onKeyDown={handleKey}
                    placeholder="Paste website URL here..."
                    className="w-full pl-12 pr-4 py-4 glass neon-border rounded-xl text-white placeholder-slate-600 bg-transparent text-sm focus:ring-0 transition-all duration-300"
                  />
                </div>
                <button
                  onClick={handleScan}
                  className="btn-cyan px-6 py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <Search className="w-4 h-4" />
                  Scan URL
                </button>
              </div>

              {/* Quick checks */}
              <div className="flex flex-wrap gap-4">
                {['Free Analysis', 'No Registration', 'Instant Results', 'Export Report'].map(item => (
                  <div key={item} className="flex items-center gap-1.5 text-xs text-slate-500">
                    <CheckCircle className="w-3.5 h-3.5 text-cyan-500" />
                    {item}
                  </div>
                ))}
              </div>
            </div>

            {/* Right — shield animation */}
            <div className="hidden lg:block">
              <ShieldAnimation />
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="border-y border-cyan-500/10 glass">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-2xl font-black neon-text mb-1">{stat.value}</div>
                <div className="text-xs text-slate-500 uppercase tracking-widest">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Cards */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-4">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs text-slate-400 tracking-widest uppercase">Core Features</span>
            </div>
            <h2 className="text-3xl font-black text-white mb-3">
              Advanced <span className="neon-text">Security</span> Features
            </h2>
            <p className="text-slate-500 max-w-md mx-auto">
              Multi-layered protection powered by intelligent URL analysis and threat intelligence.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <div
                key={i}
                className={`glass card-hover rounded-2xl p-6 border ${f.border} cursor-pointer`}
                onClick={() => onNavigate('scanner')}
              >
                <div className={`w-12 h-12 ${f.bg} border ${f.border} rounded-xl flex items-center justify-center mb-4`}>
                  <f.icon className={`w-6 h-6 ${f.color}`} />
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{f.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
                <div className={`mt-4 flex items-center gap-1 text-xs ${f.color} font-medium`}>
                  Learn more <ChevronRight className="w-3 h-3" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-950/10 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto relative">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-4">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs text-slate-400 tracking-widest uppercase">How It Works</span>
            </div>
            <h2 className="text-3xl font-black text-white mb-3">
              Simple <span className="neon-text">4-Step</span> Process
            </h2>
            <p className="text-slate-500 max-w-md mx-auto">
              Our intelligent system analyzes URLs in seconds to keep you safe online.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <div key={i} className="relative">
                {/* Connector line */}
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-full w-full h-px bg-gradient-to-r from-cyan-500/40 to-transparent z-0" style={{ width: 'calc(100% - 2.5rem)', left: '2.5rem' }} />
                )}
                <div className="glass neon-border rounded-2xl p-6 relative z-10 card-hover">
                  <div className="text-5xl font-black text-cyan-500/15 mb-3 leading-none">{step.num}</div>
                  <div className="w-10 h-10 bg-cyan-500/10 border border-cyan-500/30 rounded-lg flex items-center justify-center mb-3">
                    <step.icon className="w-5 h-5 text-cyan-400" />
                  </div>
                  <h3 className="text-white font-bold mb-2">{step.title}</h3>
                  <p className="text-slate-500 text-sm">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="glass neon-border rounded-3xl p-10 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-blue-500/5 to-cyan-500/5 pointer-events-none" />
            <Shield className="w-14 h-14 text-cyan-400 mx-auto mb-4 drop-shadow-[0_0_15px_rgba(0,212,255,0.5)]" />
            <h2 className="text-3xl font-black text-white mb-3">
              Stay Protected. <span className="neon-text">Scan Now.</span>
            </h2>
            <p className="text-slate-400 mb-8 max-w-lg mx-auto">
              Don't let phishing attacks compromise your security. Analyze any URL in seconds.
            </p>
            <button
              onClick={() => onNavigate('scanner')}
              className="btn-cyan px-8 py-4 rounded-xl font-bold text-base inline-flex items-center gap-2"
            >
              <Zap className="w-5 h-5" />
              Start Free Scan
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-cyan-500/10 py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-slate-600 text-sm">
            <Shield className="w-4 h-4 text-cyan-500/50" />
            <span>© 2024 PhishDetect — Cybersecurity Protection System</span>
          </div>
          <div className="text-slate-700 text-xs">For educational & research purposes</div>
        </div>
      </footer>
    </div>
  );
}
