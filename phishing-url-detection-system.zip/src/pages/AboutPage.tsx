import {
  Shield, AlertTriangle, Lock, Eye, CheckCircle, Globe,
  Users, BookOpen, Zap, Heart, ExternalLink
} from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: string) => void;
}

const tips = [
  {
    icon: Globe,
    title: 'Check the URL carefully',
    desc: 'Always verify the URL before entering personal information. Phishing sites often mimic real domains with slight misspellings.',
    color: 'text-cyan-400',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/25',
  },
  {
    icon: Lock,
    title: 'Look for HTTPS',
    desc: 'Ensure websites use HTTPS with a valid SSL certificate. Never enter passwords on HTTP sites.',
    color: 'text-green-400',
    bg: 'bg-green-500/10',
    border: 'border-green-500/25',
  },
  {
    icon: AlertTriangle,
    title: "Don't click unknown links",
    desc: 'Avoid clicking links from unknown email senders, text messages, or social media from strangers.',
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/25',
  },
  {
    icon: Eye,
    title: 'Avoid suspicious login pages',
    desc: 'Fake login pages are the most common phishing attack. Always navigate directly to websites instead of clicking links.',
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/25',
  },
  {
    icon: Shield,
    title: 'Use security tools',
    desc: 'Use phishing detection tools like this one, browser security extensions, and keep antivirus software updated.',
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/25',
  },
  {
    icon: CheckCircle,
    title: 'Enable two-factor authentication',
    desc: 'Even if your password is stolen, 2FA can prevent unauthorized access to your accounts.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/25',
  },
];

const stats = [
  { value: '3.4B', label: 'Phishing emails sent daily', icon: AlertTriangle, color: 'text-red-400' },
  { value: '36%', label: 'Of breaches involve phishing', icon: Shield, color: 'text-orange-400' },
  { value: '$17,700', label: 'Lost per minute to phishing', icon: Zap, color: 'text-yellow-400' },
  { value: '0.1%', label: 'Users recognize phishing', icon: Eye, color: 'text-cyan-400' },
];

const techFeatures = [
  { label: 'HTTPS Protocol Detection', desc: 'Checks if the site uses secure HTTPS connections.' },
  { label: 'Suspicious Keyword Analysis', desc: 'Identifies phishing-related keywords in the URL.' },
  { label: 'Domain Age Verification', desc: 'New domains are often used for phishing campaigns.' },
  { label: 'IP Address Detection', desc: 'URLs using IPs instead of domains are suspicious.' },
  { label: 'URL Structure Analysis', desc: 'Detects unusually long URLs or redirect patterns.' },
  { label: 'SSL Certificate Check', desc: 'Verifies the presence of a valid SSL certificate.' },
];

export default function AboutPage({ onNavigate }: AboutPageProps) {
  return (
    <div className="min-h-screen grid-bg pt-16">
      {/* Hero */}
      <section className="relative px-4 pt-16 pb-12 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative animate-slide-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-6">
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs text-slate-400 tracking-widest uppercase">About This System</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-black text-white mb-4">
            About <span className="neon-text">Phishing Protection</span>
          </h1>
          <p className="text-slate-400 text-lg leading-relaxed max-w-2xl mx-auto">
            Understanding phishing attacks and how our intelligent detection system
            keeps you safe in the evolving cybersecurity landscape.
          </p>
        </div>
      </section>

      {/* What is phishing */}
      <section className="px-4 pb-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 mb-16">
            <div className="glass neon-border rounded-2xl p-8">
              <div className="w-12 h-12 bg-red-500/10 border border-red-500/25 rounded-xl flex items-center justify-center mb-5">
                <AlertTriangle className="w-6 h-6 text-red-400" />
              </div>
              <h2 className="text-2xl font-black text-white mb-4">What is Phishing?</h2>
              <p className="text-slate-400 leading-relaxed mb-4">
                Phishing is a type of cyberattack where malicious actors create fake websites that
                closely resemble legitimate ones to steal sensitive information such as passwords,
                credit card numbers, and personal data.
              </p>
              <p className="text-slate-400 leading-relaxed mb-4">
                These fraudulent sites are distributed through email links, social media messages,
                SMS, and other communication channels, often using urgent or fear-inducing language
                to trick users into acting quickly without verifying the source.
              </p>
              <p className="text-slate-400 leading-relaxed">
                Phishing attacks account for over <span className="text-cyan-400 font-semibold">90% of data breaches</span> globally,
                making it one of the most prevalent and dangerous cyber threats today.
              </p>
            </div>

            <div className="glass neon-border rounded-2xl p-8">
              <div className="w-12 h-12 bg-cyan-500/10 border border-cyan-500/25 rounded-xl flex items-center justify-center mb-5">
                <Shield className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-black text-white mb-4">How Our System Helps</h2>
              <p className="text-slate-400 leading-relaxed mb-4">
                The Phishing URL Detection System helps users identify suspicious websites
                before they become victims. Our multi-layered analysis engine examines URLs
                across multiple security dimensions simultaneously.
              </p>
              <p className="text-slate-400 leading-relaxed mb-4">
                By analyzing URL patterns, domain reputation, SSL certificates, and keyword
                presence, we provide instant threat assessments with actionable recommendations.
              </p>
              <div className="flex gap-3 flex-wrap mt-5">
                <button
                  onClick={() => onNavigate('scanner')}
                  className="btn-cyan px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2"
                >
                  <Zap className="w-4 h-4" /> Try the Scanner
                </button>
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="px-4 py-2 rounded-lg text-sm font-semibold text-slate-400 border border-slate-700 hover:border-cyan-500/40 hover:text-cyan-400 transition-all flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" /> View Dashboard
                </button>
              </div>
            </div>
          </div>

          {/* Phishing Stats */}
          <div className="mb-16">
            <h2 className="text-2xl font-black text-white mb-6 text-center">
              Phishing by the <span className="neon-text">Numbers</span>
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {stats.map((stat, i) => (
                <div key={i} className="glass neon-border rounded-2xl p-6 text-center card-hover">
                  <stat.icon className={`w-8 h-8 ${stat.color} mx-auto mb-3`} />
                  <div className={`text-3xl font-black ${stat.color} mb-1`}>{stat.value}</div>
                  <div className="text-xs text-slate-500 leading-tight">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Detection Technology */}
          <div className="mb-16">
            <h2 className="text-2xl font-black text-white mb-2 text-center">
              Detection <span className="neon-text">Technology</span>
            </h2>
            <p className="text-slate-500 text-center mb-8 max-w-lg mx-auto">
              Our system uses a combination of rule-based analysis and pattern recognition
              to evaluate URLs across multiple security dimensions.
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {techFeatures.map((f, i) => (
                <div key={i} className="glass neon-border rounded-xl p-5 card-hover">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="text-white font-semibold text-sm mb-1">{f.label}</div>
                      <div className="text-slate-500 text-xs leading-relaxed">{f.desc}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cybersecurity Tips */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass neon-border mb-4">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-xs text-slate-400 tracking-widest uppercase">Security Tips</span>
              </div>
              <h2 className="text-2xl font-black text-white">
                Stay Safe <span className="neon-text">Online</span>
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {tips.map((tip, i) => (
                <div key={i} className={`glass rounded-2xl p-6 border ${tip.border} card-hover`}>
                  <div className={`w-10 h-10 ${tip.bg} border ${tip.border} rounded-xl flex items-center justify-center mb-4`}>
                    <tip.icon className={`w-5 h-5 ${tip.color}`} />
                  </div>
                  <h3 className="text-white font-bold mb-2 text-sm">{tip.title}</h3>
                  <p className="text-slate-500 text-xs leading-relaxed">{tip.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* About Project */}
          <div className="glass neon-border rounded-2xl p-8 text-center">
            <div className="w-14 h-14 bg-cyan-500/10 border border-cyan-500/25 rounded-2xl flex items-center justify-center mx-auto mb-5">
              <Users className="w-7 h-7 text-cyan-400" />
            </div>
            <h2 className="text-2xl font-black text-white mb-4">About This Project</h2>
            <p className="text-slate-400 leading-relaxed max-w-2xl mx-auto mb-4">
              This <span className="text-cyan-400 font-semibold">Phishing URL Detection System</span> is developed as
              a final-year college project prototype demonstrating how machine learning concepts and
              URL analysis techniques can be applied to real-world cybersecurity challenges.
            </p>
            <p className="text-slate-400 leading-relaxed max-w-2xl mx-auto mb-6">
              The system simulates an AI-powered phishing detection engine that analyzes URLs
              across 8 security dimensions including HTTPS verification, domain analysis, keyword
              detection, SSL validation, and malicious pattern recognition.
            </p>
            <div className="flex items-center justify-center gap-2 text-slate-600 text-sm">
              <Heart className="w-4 h-4 text-red-500" />
              Built with React, TypeScript & Tailwind CSS
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-cyan-500/10 py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-slate-600 text-sm">
            <Shield className="w-4 h-4 text-cyan-500/50" />
            <span>© 2024 PhishDetect — Cybersecurity Protection System</span>
          </div>
          <div className="text-slate-700 text-xs">Final Year College Project — For Educational Purposes</div>
        </div>
      </footer>
    </div>
  );
}
