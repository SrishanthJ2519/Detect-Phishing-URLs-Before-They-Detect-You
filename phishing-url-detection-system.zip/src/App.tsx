import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import ScannerPage from './pages/ScannerPage';
import DashboardPage from './pages/DashboardPage';
import HistoryPage from './pages/HistoryPage';
import AboutPage from './pages/AboutPage';
import { type ScanResult } from './utils/scanSimulator';

type PageId = 'home' | 'scanner' | 'dashboard' | 'history' | 'about';

// Particle background component
function ParticleField() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Matrix rain columns */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="absolute top-0 text-cyan-500/8 text-xs font-mono leading-3 select-none"
          style={{
            left: `${8 + i * 12}%`,
            animation: `matrixRain ${6 + i * 1.5}s linear infinite`,
            animationDelay: `${i * 0.8}s`,
          }}
        >
          {'01001101 10110010 01101001 01010101 10010110 01100101 10110100 01010010'.split(' ').join('\n')}
        </div>
      ))}

      {/* Floating orbs */}
      <div
        className="absolute w-96 h-96 rounded-full opacity-30"
        style={{
          background: 'radial-gradient(circle, rgba(0,212,255,0.06) 0%, transparent 70%)',
          top: '10%',
          left: '5%',
          animation: 'float 8s ease-in-out infinite',
        }}
      />
      <div
        className="absolute w-80 h-80 rounded-full opacity-20"
        style={{
          background: 'radial-gradient(circle, rgba(0,100,255,0.08) 0%, transparent 70%)',
          bottom: '15%',
          right: '10%',
          animation: 'float 10s ease-in-out infinite',
          animationDelay: '3s',
        }}
      />
      <div
        className="absolute w-64 h-64 rounded-full opacity-15"
        style={{
          background: 'radial-gradient(circle, rgba(0,212,255,0.05) 0%, transparent 70%)',
          top: '50%',
          right: '20%',
          animation: 'float 12s ease-in-out infinite',
          animationDelay: '6s',
        }}
      />
    </div>
  );
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [scannerUrl, setScannerUrl] = useState<string>('');
  const [dashboardResult, setDashboardResult] = useState<ScanResult | null>(null);

  // Page transition
  const [transitioning, setTransitioning] = useState(false);

  const navigate = (page: string, extra?: string | ScanResult) => {
    setTransitioning(true);
    setTimeout(() => {
      setCurrentPage(page as PageId);
      if (page === 'scanner' && typeof extra === 'string') {
        setScannerUrl(extra);
      } else if (page === 'dashboard' && extra && typeof extra === 'object') {
        setDashboardResult(extra as ScanResult);
      }
      setTransitioning(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 150);
  };

  // Scanner navigation handler for ScannerPage which passes ScanResult
  const handleScannerNavigate = (page: string, result?: ScanResult) => {
    navigate(page, result);
  };

  useEffect(() => {
    // Clear scanner URL after navigation
    if (currentPage !== 'scanner') {
      setScannerUrl('');
    }
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={navigate} />;
      case 'scanner':
        return <ScannerPage initialUrl={scannerUrl} onNavigate={handleScannerNavigate} />;
      case 'dashboard':
        return <DashboardPage result={dashboardResult} onNavigate={navigate} />;
      case 'history':
        return <HistoryPage onNavigate={handleScannerNavigate} />;
      case 'about':
        return <AboutPage onNavigate={navigate} />;
      default:
        return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div className="relative min-h-screen bg-[#050a0f]">
      <ParticleField />
      <div className="relative z-10">
        <Navbar currentPage={currentPage} onNavigate={navigate} />
        <main
          className="transition-opacity duration-150"
          style={{ opacity: transitioning ? 0 : 1 }}
        >
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
