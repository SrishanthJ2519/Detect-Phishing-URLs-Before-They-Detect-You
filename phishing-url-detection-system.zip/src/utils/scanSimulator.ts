export interface ScanResult {
  url: string;
  domain: string;
  status: 'SAFE' | 'PHISHING' | 'SUSPICIOUS';
  riskScore: number;
  threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  scanTime: string;
  date: string;
  checks: {
    httpsCheck: boolean;
    domainAnalysis: boolean;
    suspiciousKeywords: boolean;
    urlStructure: boolean;
    ipDetection: boolean;
    sslCertificate: boolean;
    domainAge: boolean;
    maliciousPattern: boolean;
  };
  detectedIssues: string[];
  recommendation: string;
  urlReputation: number;
  securityScore: number;
}

const PHISHING_KEYWORDS = [
  'login', 'signin', 'account', 'verify', 'update', 'secure', 'bank',
  'paypal', 'amazon', 'microsoft', 'google', 'apple', 'netflix',
  'password', 'credential', 'confirm', 'suspended', 'unusual',
  'click', 'free', 'winner', 'prize', 'urgent', 'alert', 'warning'
];

const SUSPICIOUS_TLDS = ['.xyz', '.tk', '.ml', '.ga', '.cf', '.top', '.work', '.click'];
const TRUSTED_DOMAINS = [
  'google.com', 'github.com', 'microsoft.com', 'apple.com',
  'amazon.com', 'facebook.com', 'youtube.com', 'twitter.com',
  'linkedin.com', 'stackoverflow.com', 'wikipedia.org', 'reddit.com',
  'openai.com', 'cloudflare.com', 'stripe.com', 'vercel.com',
  'netflix.com', 'spotify.com', 'adobe.com', 'salesforce.com'
];

function extractDomain(url: string): string {
  try {
    let cleaned = url.trim();
    if (!cleaned.startsWith('http')) cleaned = 'https://' + cleaned;
    const parsed = new URL(cleaned);
    return parsed.hostname.replace('www.', '');
  } catch {
    return url.trim().replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
  }
}

function hasIP(url: string): boolean {
  return /\b(\d{1,3}\.){3}\d{1,3}\b/.test(url);
}

function hasLongUrl(url: string): boolean {
  return url.length > 75;
}

function hasMultipleSubdomains(url: string): boolean {
  const domain = extractDomain(url);
  return domain.split('.').length > 3;
}

function hasPhishingKeyword(url: string): boolean {
  const lower = url.toLowerCase();
  return PHISHING_KEYWORDS.some(kw => lower.includes(kw));
}

function hasSuspiciousTLD(domain: string): boolean {
  return SUSPICIOUS_TLDS.some(tld => domain.endsWith(tld));
}

function isTrusted(domain: string): boolean {
  return TRUSTED_DOMAINS.some(trusted => domain === trusted || domain.endsWith('.' + trusted));
}

function hasHTTPS(url: string): boolean {
  const lower = url.toLowerCase();
  if (lower.startsWith('http://')) return false;
  if (lower.startsWith('https://')) return true;
  return true; // assume https if no prefix
}

function hasSpecialChars(url: string): boolean {
  return /@|%40|\.\./.test(url);
}

export function simulateScan(url: string): Promise<ScanResult> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const domain = extractDomain(url);
      const isIP = hasIP(url);
      const isLong = hasLongUrl(url);
      const multiSub = hasMultipleSubdomains(url);
      const phishingKw = hasPhishingKeyword(url);
      const suspTLD = hasSuspiciousTLD(domain);
      const trusted = isTrusted(domain);
      const https = hasHTTPS(url);
      const specialChars = hasSpecialChars(url);

      // Calculate base risk
      let riskScore = 0;
      const issues: string[] = [];

      if (trusted) {
        riskScore = Math.floor(Math.random() * 12) + 2;
      } else {
        if (isIP) { riskScore += 30; issues.push('IP address used instead of domain name'); }
        if (!https) { riskScore += 20; issues.push('No HTTPS security protocol detected'); }
        if (phishingKw) { riskScore += 20; issues.push('Suspicious phishing keywords in URL'); }
        if (isLong) { riskScore += 10; issues.push('Unusually long URL length detected'); }
        if (multiSub) { riskScore += 15; issues.push('Multiple suspicious subdomains'); }
        if (suspTLD) { riskScore += 25; issues.push('Suspicious top-level domain detected'); }
        if (specialChars) { riskScore += 15; issues.push('Special characters detected in URL'); }

        // Add randomness
        riskScore += Math.floor(Math.random() * 15);
        riskScore = Math.min(98, riskScore);
      }

      // Determine status
      let status: 'SAFE' | 'PHISHING' | 'SUSPICIOUS';
      let threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

      if (riskScore <= 20) {
        status = 'SAFE';
        threatLevel = 'LOW';
      } else if (riskScore <= 45) {
        status = 'SUSPICIOUS';
        threatLevel = 'MEDIUM';
      } else if (riskScore <= 70) {
        status = 'PHISHING';
        threatLevel = 'HIGH';
      } else {
        status = 'PHISHING';
        threatLevel = 'CRITICAL';
      }

      const checks = {
        httpsCheck: https,
        domainAnalysis: !multiSub && !isIP,
        suspiciousKeywords: !phishingKw,
        urlStructure: !isLong && !specialChars,
        ipDetection: !isIP,
        sslCertificate: https && riskScore < 60,
        domainAge: !suspTLD && riskScore < 50,
        maliciousPattern: riskScore < 40,
      };

      let recommendation = '';
      if (status === 'SAFE') {
        recommendation = 'This website appears to be legitimate and safe. Standard browsing precautions still apply.';
      } else if (status === 'SUSPICIOUS') {
        recommendation = 'This website shows suspicious characteristics. Avoid entering personal information and proceed with caution.';
      } else {
        recommendation = 'WARNING: This website is likely a phishing site. Do NOT enter any personal information, passwords, or payment details. Leave immediately.';
      }

      const now = new Date();
      const result: ScanResult = {
        url: url.trim(),
        domain,
        status,
        riskScore,
        threatLevel,
        scanTime: `${(Math.random() * 2 + 0.5).toFixed(2)}s`,
        date: now.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' }),
        checks,
        detectedIssues: issues,
        recommendation,
        urlReputation: Math.max(0, 100 - riskScore),
        securityScore: Math.max(0, 100 - riskScore),
      };

      resolve(result);
    }, 3000 + Math.random() * 1500);
  });
}

export function getStoredHistory(): ScanResult[] {
  try {
    const data = localStorage.getItem('phishing_scan_history');
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function addToHistory(result: ScanResult): void {
  try {
    const history = getStoredHistory();
    const updated = [result, ...history].slice(0, 50);
    localStorage.setItem('phishing_scan_history', JSON.stringify(updated));
  } catch {
    // ignore
  }
}

export function clearHistory(): void {
  localStorage.removeItem('phishing_scan_history');
}
