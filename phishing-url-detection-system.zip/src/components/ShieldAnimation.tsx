export default function ShieldAnimation() {
  return (
    <div className="relative flex items-center justify-center w-64 h-64 mx-auto float-anim">
      {/* Outer pulse rings */}
      <div className="absolute inset-0 rounded-full border border-cyan-500/20 animate-ping" style={{ animationDuration: '3s' }} />
      <div className="absolute inset-4 rounded-full border border-cyan-500/15 animate-ping" style={{ animationDuration: '2.5s', animationDelay: '0.5s' }} />
      <div className="absolute inset-8 rounded-full border border-cyan-400/10 animate-ping" style={{ animationDuration: '2s', animationDelay: '1s' }} />

      {/* Rotating ring */}
      <div className="absolute inset-2 rounded-full border-2 border-dashed border-cyan-500/20 animate-spin-slow" />

      {/* Hexagon grid background */}
      <div className="absolute inset-10 flex items-center justify-center opacity-20">
        <div className="grid grid-cols-3 gap-1">
          {[...Array(9)].map((_, i) => (
            <div key={i} className="w-4 h-4 hexagon bg-cyan-400/40" />
          ))}
        </div>
      </div>

      {/* Center shield */}
      <div className="relative z-10 w-28 h-28 flex items-center justify-center">
        <div className="absolute inset-0 bg-cyan-500/10 rounded-full blur-xl" />
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_20px_rgba(0,212,255,0.6)]">
          <defs>
            <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#0066ff" stopOpacity="0.7" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <path
            d="M50 8 L85 22 L85 52 C85 72 50 92 50 92 C50 92 15 72 15 52 L15 22 Z"
            fill="url(#shieldGrad)"
            fillOpacity="0.15"
            stroke="url(#shieldGrad)"
            strokeWidth="2"
            filter="url(#glow)"
          />
          <path
            d="M50 20 L75 30 L75 52 C75 65 50 80 50 80 C50 80 25 65 25 52 L25 30 Z"
            fill="url(#shieldGrad)"
            fillOpacity="0.1"
            stroke="url(#shieldGrad)"
            strokeWidth="1"
            strokeOpacity="0.5"
          />
          {/* Lock icon inside shield */}
          <rect x="40" y="47" width="20" height="16" rx="2" fill="#00d4ff" fillOpacity="0.7" />
          <path
            d="M43 47 L43 43 C43 38 57 38 57 43 L57 47"
            fill="none"
            stroke="#00d4ff"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <circle cx="50" cy="55" r="2" fill="#050a0f" fillOpacity="0.8" />
        </svg>
      </div>

      {/* Scan line overlay */}
      <div className="absolute inset-0 rounded-full overflow-hidden pointer-events-none">
        <div className="absolute left-0 right-0 h-px scan-line" style={{ top: '30%' }} />
      </div>

      {/* Corner dots */}
      {[
        'top-4 left-4', 'top-4 right-4',
        'bottom-4 left-4', 'bottom-4 right-4'
      ].map((pos, i) => (
        <div
          key={i}
          className={`absolute ${pos} w-2 h-2 rounded-full bg-cyan-400`}
          style={{ boxShadow: '0 0 8px rgba(0,212,255,0.8)', animationDelay: `${i * 0.3}s` }}
        />
      ))}
    </div>
  );
}
