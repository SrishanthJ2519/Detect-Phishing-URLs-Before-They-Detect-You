import { useState } from 'react';
import { Shield, Menu, X, Zap } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'scanner', label: 'Scanner' },
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'history', label: 'History' },
  { id: 'about', label: 'About' },
];

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-strong border-b border-cyan-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 group"
          >
            <div className="relative">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/40 flex items-center justify-center group-hover:border-cyan-400/70 transition-all duration-300">
                <Shield className="w-5 h-5 text-cyan-400 group-hover:text-cyan-300 transition-colors" />
              </div>
              <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-cyan-400 rounded-full animate-blink" />
            </div>
            <div className="text-left">
              <div className="text-sm font-bold text-cyan-400 leading-none tracking-wider">PhishDetect</div>
              <div className="text-xs text-slate-500 leading-none mt-0.5">URL Security Scanner</div>
            </div>
          </button>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`nav-link px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  currentPage === item.id
                    ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-cyan-300 hover:bg-cyan-500/5'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-green-400">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-blink" />
              System Online
            </div>
            <button
              onClick={() => onNavigate('scanner')}
              className="btn-cyan px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5" />
              Scan URL
            </button>
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden text-slate-400 hover:text-cyan-400 transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden glass border-t border-cyan-500/20 animate-fade-in">
          <div className="px-4 py-3 space-y-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => { onNavigate(item.id); setMenuOpen(false); }}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  currentPage === item.id
                    ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-500/25'
                    : 'text-slate-400 hover:text-cyan-300 hover:bg-cyan-500/5'
                }`}
              >
                {item.label}
              </button>
            ))}
            <div className="pt-2">
              <button
                onClick={() => { onNavigate('scanner'); setMenuOpen(false); }}
                className="btn-cyan w-full px-4 py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                Scan URL
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
